import java.io.*;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;
import java.util.*;

public class TicketCancellation {
    private static String TicketFilePath = "TicketDetails.csv";
    private static String filePath = "BusDetails.csv";
    private static Scanner scanner = new Scanner(System.in);
    public static String deleteTicketData(String busIdValue, String nameValue, String phoneValue) throws IOException {
        List<List<String>> rows = new ArrayList<>();
        int busIdIndex = -1;
        int nameIndex = -1;
        int phoneIndex = -1;
        String seatNumber = "-1";

        try (BufferedReader reader = new BufferedReader(new FileReader(TicketFilePath))) {
            String line;
            if ((line = reader.readLine()) != null) {
                String[] headers = line.split(",");
                for (int i = 0; i < headers.length; i++) {
                    if (headers[i].trim().equalsIgnoreCase("BusId")) {
                        busIdIndex = i;
                    } else if (headers[i].trim().equalsIgnoreCase("Name")) {
                        nameIndex = i;
                    } else if (headers[i].trim().equalsIgnoreCase("Phone")) {
                        phoneIndex = i;
                    }
                }
                if (busIdIndex == -1 || nameIndex == -1 || phoneIndex == -1) {
                    System.out.println("The details are not found for any ticket\n please try again");
                    return "-1";
                }
            }

            while ((line = reader.readLine()) != null) {
                String[] values = line.split(",");
                if (values.length > busIdIndex && values.length > nameIndex && values.length > phoneIndex &&
                    values[busIdIndex].trim().equalsIgnoreCase(busIdValue.trim()) &&
                    values[nameIndex].trim().equalsIgnoreCase(nameValue.trim()) &&
                    values[phoneIndex].trim().equalsIgnoreCase(phoneValue.trim())) {
                    seatNumber = values[13];
                    continue;
                }
                List<String> row = new ArrayList<>(Arrays.asList(values));
                rows.add(row);
            }

            try (BufferedWriter writer = new BufferedWriter(new FileWriter(TicketFilePath))) {
                writer.write("Date,BusId,Name,Age,Gender,Boarding Point,Departure Date,Time,Drop Point,Drop Date,Drop Time,Price,Phone,Seat,Date of Booking\n");
                for (List<String> row : rows) {
                    writer.write(String.join(",", row));
                    writer.newLine();
                }
            }
            return seatNumber;
        }
    }

    public static boolean searchBus(String busId, String date) {
        String line, bus[];
        List<String[]> allRows = new ArrayList<>();
        try (FileReader file = new FileReader(TicketFilePath);
             BufferedReader br = new BufferedReader(file)) {
            while ((line = br.readLine()) != null) {
                bus = line.split(",");
                allRows.add(bus);
                if (bus.length > 2 && bus[1].equals(busId) && bus[0].equals(date)) {
                    return true;
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return false;
    }

    public static boolean checkCancellationPolicy(long daysDifference) {
        if (daysDifference == 0) {
            System.out.println("The ticket you are trying to cancel is not cancellable\n"
                               + "due to the last day of boarding of bus");
            return true;
        } else if (daysDifference == 1) {
            System.out.println("You can get only 25% of your bus fare \n"
                               + "according to the cancellation policy");
            return true;
        } else if (daysDifference == 2) {
            System.out.println("You can get only 50% of your bus fare \n"
                               + "according to the cancellation policy");
            return true;
        } else if (daysDifference >= 3) {
            System.out.println("You can get only 75% of your bus fare\n"
                               + "according to the cancellation policy");
            return true;
        } else {
            System.out.println("You are not eligible for ticket cancellation\n"
                               + "due to either your bus is departured earlier\n"
                               + "or it is not scheduled");
            return false;
        }
    }

    public static String TimeBeforeDeparture() {
        LocalDateTime currentDateTime = LocalDateTime.now();
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd-MM-yyyy");
        return currentDateTime.format(formatter);
    }

    public static int calculateDaysDifference(String date1, String date2, String dateFormat) {
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern(dateFormat);
        LocalDate localDate1 = LocalDate.parse(date1, formatter);
        LocalDate localDate2 = LocalDate.parse(date2, formatter);
        long daysDifference = ChronoUnit.DAYS.between(localDate2, localDate1);
        return (int) daysDifference;
    }

    public static void updateBusSeat(String csvFilePath, int rowIndex, int columnIndex, String newValue) throws IOException {
        List<String[]> rows = new ArrayList<>();
        try (BufferedReader reader = new BufferedReader(new FileReader(csvFilePath))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] row = line.split(",");
                rows.add(row);
            }
        }

        if (rowIndex >= 0 && rowIndex < rows.size() && columnIndex >= 0 && columnIndex < rows.get(rowIndex).length) {
            rows.get(rowIndex)[columnIndex] = newValue;
        } else {
            System.out.println("Invalid row or column index.");
            return;
        }

        try (BufferedWriter writer = new BufferedWriter(new FileWriter(csvFilePath))) {
            for (String[] row : rows) {
                writer.write(String.join(",", row));
                writer.newLine();
            }
        }

        System.out.println("Ticket Cancelled successfully.");
    }

    public static int findColumnForBusIdAndDate(String csvFilePath, String busId, String date) throws IOException {
    	int busIdColumnIndex = -1;
        int dateColumnIndex = -1;
        List<String[]> rows = new ArrayList<>();

        try (BufferedReader reader = new BufferedReader(new FileReader(csvFilePath))) {
            String line;
            String[] headers = null;

            if ((line = reader.readLine()) != null) {
                headers = line.split(",");
                for (int i = 0; i < headers.length; i++) {
                    if (headers[i].trim().equalsIgnoreCase("BusId")) {
                        busIdColumnIndex = i;
                    } else if (headers[i].trim().equalsIgnoreCase("Date")) {
                        dateColumnIndex = i;
                    }
                }

                if (busIdColumnIndex == -1 || dateColumnIndex == -1) {
                    System.out.println("BusId or Date column not found in CSV header.");
                    return -1;
                }
            }

            int rowIndex = 1; // Start from 1 because 0 is the header row
            while ((line = reader.readLine()) != null) {
                String[] row = line.split(",");
                if (row.length > busIdColumnIndex && row.length > dateColumnIndex) {
                    if (row[busIdColumnIndex].trim().equals(busId) && row[dateColumnIndex].trim().equals(date)) {
                        return rowIndex;
                    }
                }
                rowIndex++;
            }
        }

        System.out.println("Matching Bus ID and Date not found.");
        return -1;
    }
    
    public static void cancelPassengerTicket() throws IOException {
        System.out.println("Enter Passenger Name      : ");
        String name = scanner.nextLine();
        System.out.println("Enter Bus number          : ");
        String busId = scanner.nextLine();     
        System.out.println("Enter Phone number        : ");
        String phone = scanner.nextLine();
        System.out.println("Departure Date dd-mm-yyyy : ");
        String date = scanner.nextLine();
        String currentDate = TimeBeforeDeparture();
        int daysDifference = calculateDaysDifference(date,currentDate,"dd-MM-yyyy");
        
        if (searchBus(busId,date)) {
        	
        	if (checkCancellationPolicy(daysDifference)) {
        		String seatNo = deleteTicketData(busId,name,phone);
        		int seatNum = Integer.parseInt(seatNo);
        		
        		int columnIndex = findColumnForBusIdAndDate(filePath, busId,date);
        		if (columnIndex != -1 && seatNum > 0) {
                    updateBusSeat(filePath, columnIndex, seatNum+7, "0");
        		}
        	    else {
                System.out.println("Bus ID " + busId + " not found in the CSV file.");
        	    }
        	}
        }
        else {
        		System.out.println("Invalid Details for cancellation ticket...\nplease try again...");
        	}
        }	
}