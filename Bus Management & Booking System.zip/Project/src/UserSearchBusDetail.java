import java.util.Scanner;

public class UserSearchBusDetail {
	private static Scanner sc = new Scanner(System.in);
    public static void enter() throws Exception {
        
        System.out.println("Enter Filter For Your Bus Findings : ");
        System.out.println("Boarding Point: ");
        String boardingPoint = sc.nextLine();
        System.out.println("Dropping Point: ");
        String dropPoint = sc.nextLine();
        System.out.println("Date          : ");
        String date = sc.nextLine();
        
        RunCsvFile runCsvFile = new RunCsvFile();
        runCsvFile.searchBus(boardingPoint, dropPoint, date);
        System.out.println("According to your preferences select Bus number for booking : ");
        String busId = sc.nextLine();
        SeatSlotView.realTimeSeatView(busId,date);
        userChoice(busId,boardingPoint, dropPoint,date);
        
    }
    
    public static void enterBusno(String date,String boardingPoint, String dropPoint) throws Exception {
    	System.out.println("According to your preferences select Bus number for booking : ");
        String busNum = sc.nextLine();
        SeatSlotView.realTimeSeatView(busNum,date);
        userChoice(busNum,boardingPoint, dropPoint,date);
    }

    public static void userChoice(String busId, String boardingPoint,String dropPoint,String date) throws Exception {
    	System.out.println("-----------------------------------------------------------------------------");
        System.out.println("Did you want to book seat on this bus "+busId+"\n"
        				+ " 1 for continue booking\n"
        				+ " 2 for seeing other bus on same route\n"
        				+ " 3 for Search Bus Again\n"
        				+ " 4 for go to main menu");
        int ch = sc.nextInt();
        sc.nextLine(); 
        switch(ch) {
        	case 1:
        		System.out.println("Enter number of seats for reservation : ");
                int noOfSeat = sc.nextInt();
                sc.nextLine(); 
                SeatBooking.bookSeat(busId, noOfSeat,date);
                break;
        	case 2:
        		RunCsvFile runCsvFile = new RunCsvFile();
        		runCsvFile.searchBus(boardingPoint, dropPoint, date);
        		enterBusno(date,boardingPoint,dropPoint);
        		break;
        	case 3:
        		enter();
        		break;
        	case 4:
        		break;
        	default:
        		System.out.println("Invalid Input!!! Try Again...");
        		System.out.println();
        		
        }
    	
    }
}
