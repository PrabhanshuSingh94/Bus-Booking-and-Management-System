import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.util.*;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;


public class SeatBooking {
	//private static String[] bus;
	private static Scanner scanner = new Scanner(System.in);
	private static String filePath = "BusDetails.csv";
	private static String ticketDetailsFile = "TicketDetails.csv";
	
	public static String CurrentDateTime() {
        
        LocalDateTime currentDateTime = LocalDateTime.now();

        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");

        String formattedDateTime = currentDateTime.format(formatter);

        return formattedDateTime;
    }
	
		
	public static void bookSeat(String busId, int noOfSeat,String busDate) {
		RunCsvFile runCsvFile = new RunCsvFile();
        runCsvFile.searchBus(busId, busDate);
        String[] busDetails = runCsvFile.getBusDetails();

        if (busDetails == null) {
            System.out.println("No bus details found for the given Bus ID and Date.");
            return;
        }

        runCsvFile.readAllRows();
        List<String[]> allRows = runCsvFile.getAllRows();
        for (int i = 0; i < noOfSeat; i++) {
            boolean isBooked = false;

            System.out.println("Choose Your Seat No. : ");
            int seatNo = scanner.nextInt();

            // Find the row for the specified busId
            int rowIndex = -1;
            for (int j = 0; j < allRows.size(); j++) {
                if (allRows.get(j)[4].equals(busId)) {
                    rowIndex = j;
                    break;
                }
            }

            if (rowIndex == -1) {
                System.out.println("Bus ID not found.");
                return;
            }

            String[] bus = allRows.get(rowIndex);

            if (seatNo < 1 || seatNo > bus.length - 8) {
                System.out.println("Invalid Seat number.");
            } else if (bus[seatNo + 7].equals("1")) {
                System.out.println("Sorry, the Seat number " + seatNo + " is already reserved.");
                System.out.println("Please try another seat or 0 for cancel");
                bookSeat(busId, noOfSeat - i, busDate);
                return;
            } else {
                bus[seatNo + 7] = "1";
                isBooked = true;
                allRows.set(rowIndex, bus);
            }

            if (isBooked) {
                try (BufferedWriter bw = new BufferedWriter(new FileWriter(filePath))) {
                    for (String[] row : allRows) {
                        bw.write(String.join(",", row));
                        bw.newLine();
                    }
                    System.out.println("Please Enter the Passenger Details for Seat " + seatNo);
                    scanner.nextLine(); 
                    System.out.print("Passenger Name   : ");
                    String name = scanner.nextLine();
                    System.out.print("Passenger Age    : ");
                    String age = scanner.nextLine();
                    System.out.print("Passenger Gender : ");
                    String gender = scanner.nextLine();
                    System.out.print("Passenger Phone  : ");
                    String phone = scanner.nextLine();
                    String date = CurrentDateTime();
                    try (FileWriter writer = new FileWriter(ticketDetailsFile, true)) {
                        writer.append(busDetails[0] + "," + busDetails[4] + "," + name + "," + age + "," + gender + "," + busDetails[5] + ","
                                + busDetails[0] + "," + busDetails[1] + "," + busDetails[6] + "," + busDetails[2] + "," + busDetails[3]
                                + "," + busDetails[7] + "," + phone + "," + seatNo + "," + date + "\n");
                        System.out.println("You have booked your seat successfully.");
                    }
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
    }
}
