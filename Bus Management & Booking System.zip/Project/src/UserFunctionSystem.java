import java.io.*;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.*;

public class UserFunctionSystem {

    //private static String filePath = "BusDetails.csv";
    private static String TicketFilePath = "TicketDetails.csv";
    private static String passengerFeedbackDB = "passengerFeedback.csv";
    private static Scanner scanner = new Scanner(System.in);

    

    public static void printTicket() throws Exception {
        System.out.println("Download Your Bus Ticket");
        System.out.print("Name              : ");
        String name = scanner.nextLine();
        System.out.print("Phone             : ");
        String phone = scanner.nextLine();
        System.out.print("Date {dd:mm:yyyy} : ");
        String date = scanner.nextLine();
        
        String line;
        List<String[]> allRows = new ArrayList<>();
        String[] passengerDetails = new String[15];
        String[] allDetails;
        boolean matchFound = false;
        File files = new File(TicketFilePath);
      
        try (FileReader file = new FileReader(TicketFilePath);
             BufferedReader br = new BufferedReader(file)) {
            while ((line = br.readLine()) != null) {
                if (line.trim().isEmpty()) continue; 
                allDetails = line.split(",");
                allRows.add(allDetails);

                if (allDetails.length > 1 && allDetails[2].equals(name)
                        && allDetails[12].equals(phone)
                        && allDetails[0].equals(date)) {
                    for (int i = 0; i < 15; i++) {
                        passengerDetails[i] = allDetails[i];
                    }
                    matchFound = true;
                    System.out.println("Debug: Match found - " + Arrays.toString(passengerDetails));
                    break; // Exit loop once match is found
                }
            }
        } catch (IOException e) {
        	System.out.println("Debug: IOException occurred - " + e.getMessage());
            e.printStackTrace();
        }

        if (matchFound) {
            DownloadTicket.generateTicket(passengerDetails);
        } else {
            System.out.println("No details found");
        }
    }

    public static void main(String[] args) throws Exception {
        int run = 1;
        System.out.println("Singh's Tour and travel Company");
        System.out.println("Welcome to the Online Ticket Booking ");
        System.out.println("Note : Whenever you want to exit please press 0.");

        while (run == 1) {
            System.out.println("Press 1 : View Buses\n"
                    + "Press 2 : Download Your Ticket\n"
                    + "Press 3 : Cancel Your Ticket\n"
                    + "Press 4 : Give Feedback\n"
                    + "Press 5 : View User Feeedback Rating\n"
                    + "Press 6 : User Feedback Read\n"
                    + "Press 0 : Exit the Interface\n");

            if (scanner.hasNextInt()) {
                int press = scanner.nextInt();
                scanner.nextLine(); // Consume the newline character

                switch (press) {
                    case 1:
                        UserSearchBusDetail.enter();
                        break;
                    case 2:
                        printTicket();
                        break;
                    case 3:
                    	TicketCancellation.cancelPassengerTicket();
                        break;
                    case 4:
                    	passengerFeedbackForm.FeedbackForm();
                    	break;
                    case 5:
                    	passengerFeedbackForm.showRating(passengerFeedbackDB);
                    	break;
                    case 6:
                    	FeedbackProcessor.displayFeedback();
                    	break;
                    case 0:
                        run = 0;
                        break;
                    default:
                        System.out.println("Invalid Choice!!!");
                        break;
                }
            } else {
                System.out.println("Invalid input! Please enter a valid number.");
                scanner.nextLine(); 
            }
        }
        scanner.close();
    }
}
