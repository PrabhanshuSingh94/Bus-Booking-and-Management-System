public class SeatSlotView {
	
    public static void realTimeSeatView(String busId, String date) throws Exception {
        RunCsvFile runCsvFile = new RunCsvFile();
        runCsvFile.searchBus(busId, date);
        String[] busDetails = runCsvFile.getBusDetails();
        int[] busCapacity = runCsvFile.getBusCapacity();
        
        if (busCapacity.length == 1) {
        	System.out.println("Invalid Bus Number... Please Try Again!!!");
        	UserSearchBusDetail.enter();
        	return;
        }
        int count = 1;
        System.out.println("___________________________________________________");
        System.out.println("Welcome to Singh's Travel. This is bus " + busId);
        System.out.println("Route : " + busDetails[5] + "[" + busDetails[0] + "] to " + busDetails[6] + "[" + busDetails[2] + "]");
        System.out.println("Departure Time  : " + busDetails[1] + " | Destination Time : " + busDetails[3]);

        System.out.println(" |-------------------------------------------------|");
        System.out.print(" | ");

        for (int i = 0; i < busCapacity.length; i++) {
            if (i < 2) {
                if (busCapacity[i] == 0) {
                    if (i == 0) {
                        System.out.print(i + 1 + "  Window");
                        count++;
                    } else {
                        System.out.print(i + 1 + "  Seat ");
                        count++;
                    }
                } else {
                    System.out.print("   Booked");
                    count++;
                }
                if (count > 2) {
                    System.out.println("              <| Driver |>");
                    count = 1;
                }
                System.out.print(" | ");
            } else {
                if (i < 9) {
                    if (busCapacity[i] == 0) {
                        if (count == 1 || count == 4) {
                            System.out.print(i + 1 + "  Window");
                            count++;
                        } else {
                            System.out.print(i + 1 + "  Seat  ");
                            count++;
                        }
                    } else if (busCapacity[i] == 1) {
                        System.out.print("   Booked");
                        count++;
                    }
                    if (count >= 5) {
                        System.out.println("  |");
                        count = 1;
                    }
                    System.out.print(" | ");
                } else {
                    if (busCapacity[i] == 0) {
                        if (count == 1 || count == 4) {
                            System.out.print(i + 1 + " Window");
                            count++;
                        } else {
                            System.out.print(i + 1 + " Seat  ");
                            count++;
                        }
                    } else if (busCapacity[i] == 1) {
                        System.out.print("   Booked");
                        count++;
                    }
                    if (count >= 5) {
                        System.out.println("  |");

                        count = 1;
                    }
                    System.out.print(" | ");
                }
            }
        }
        System.out.println("------------------------------------------------|");
        System.out.println("Ticket : " + busDetails[7] + " per Seat");
    }
    
}
