import java.io.*;

import com.pdfjet.*;
import java.io.FileOutputStream;

import java.net.URL;

import com.pdfjet.Image;
import com.pdfjet.PDF;
import com.pdfjet.Page;
import com.pdfjet.Font;
import com.pdfjet.CoreFont;

public class DownloadTicket {

    public static void generateTicket(String[] busDetails) throws Exception {

    	String ticketPdfName = "DownloadedTickets/ticket"+"_"+busDetails[1]+"_"+busDetails[2]+".pdf";
        PDF pdf = new PDF(new BufferedOutputStream(new FileOutputStream(ticketPdfName)));

        Page page = new Page(pdf, Letter.PORTRAIT);

       
        Font f1 = new Font(pdf, CoreFont.HELVETICA_BOLD);
        Font f2 = new Font(pdf, CoreFont.HELVETICA);

        f1.setSize(12f);
        f2.setSize(10f);
        
     
        String imagePath = "static/BusTicket.jpeg";

        try (InputStream inputStream = new FileInputStream(imagePath)) {
            Image image = new Image(pdf, inputStream, ImageType.JPG);
            float imageX = 50f;
            float imageY = 300f;
            float scale = 0.5f;
            image.setPosition(imageX, imageY);
            image.scaleBy(scale);
            image.drawOn(page);
        } catch (IOException e) {
            e.printStackTrace();
      
        }
        
        //title
        TextLine title = new TextLine(f1, "E-Ticket");
        title.setPosition(180f, 50f);
        title.drawOn(page);

        //agency and bus number
        TextLine agency = new TextLine(f2, "Singh's Travel Agency. Your Bus number is " + busDetails[1]);
        agency.setPosition(50f, 100f);
        agency.drawOn(page);

        //departure details
        TextLine departure = new TextLine(f2, "Departure From : " + busDetails[5] + " to  " + busDetails[8]);
        departure.setPosition(50f, 120f);
        departure.drawOn(page);

        //departure time
        TextLine departureTime = new TextLine(f2, "Departure Time: On " + busDetails[6] + " before " + busDetails[7]);
        departureTime.setPosition(50f, 140f);
        departureTime.drawOn(page);

        //arrival time
        TextLine arrivalTime = new TextLine(f2, "Arrival Time  : On " + busDetails[9] + " at " + busDetails[10]);
        arrivalTime.setPosition(50f, 160f);
        arrivalTime.drawOn(page);

        // Draw passenger details
        TextLine passengerName = new TextLine(f2, "Passenger Name  : " + busDetails[2]);
        passengerName.setPosition(50f, 180f);
        passengerName.drawOn(page);

        TextLine passengerAge = new TextLine(f2, "Passenger Age   : " + busDetails[3]);
        passengerAge.setPosition(50f, 200f);
        passengerAge.drawOn(page);

        TextLine passengerGender = new TextLine(f2, "Passenger Gender: " + busDetails[4]);
        passengerGender.setPosition(50f, 220f);
        passengerGender.drawOn(page);

        TextLine seatDetails = new TextLine(f2, "Seat Number      : " + busDetails[13] + ".\n"
        									  + " Be Comfortable and Enjoy your Trip.");
        seatDetails.setPosition(50f, 240f);
        seatDetails.drawOn(page);

        //
        TextLine fareDetails = new TextLine(f2, "Fare & Payment Details");
        fareDetails.setPosition(50f, 260f);
        fareDetails.drawOn(page);

        TextLine baseFare = new TextLine(f2, "Base Fare (1 Traveller): " + busDetails[11]);
        baseFare.setPosition(50f, 280f);
        baseFare.drawOn(page);

       
        pdf.complete();
        

        System.out.println("Ticket Downloaded Successfully... Happy Journey");
    }

    
}
