import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;

import java.util.*;


public class passengerFeedbackForm {
	private static Scanner scanner = new Scanner(System.in);
	
	private static String ticketDetailsFile = "TicketDetails.csv";
    private static String passengerFeedbackDB = "passengerFeedback.csv";
    
	 public static boolean checkPassengerIdentity(String busId,String name) {
	        String line, checkPassenger[];
	        List<String[]> allRows = new ArrayList<>();
	        try (FileReader file = new FileReader(ticketDetailsFile);
	             BufferedReader br = new BufferedReader(file)) {
	            while ((line = br.readLine()) != null) {
	            	checkPassenger = line.split(",");
	                allRows.add(checkPassenger);

	                if (checkPassenger.length > 2 && checkPassenger[1].equals(busId) && checkPassenger[2].equals(name)) {
	                   return true;
	                }
	                
	                
	            }
	        } catch (IOException e) {
	        	
	            e.printStackTrace();
	        }
	        return false;
	        
	    }
	 
	 public static void showRating(String passengerFeedbackDB) {
		 int totalRatings = 0;
	        int sumRatings = 0;
	        Map<Integer, Integer> ratingCounts = new HashMap<>();

	        // Initialize a HashSet to track unique ratings
	        HashSet<Integer> uniqueRatings = new HashSet<>();

	        try (BufferedReader br = new BufferedReader(new FileReader(passengerFeedbackDB))) {
	            String line;
	            while ((line = br.readLine()) != null) {
	                String[] data = line.split(",");
	                if (data.length >= 3) { 
	                    try {
	                        int rating = Integer.parseInt(data[2]); 
	                        if (rating >= 1 && rating <= 5) {
	                            
	                            if (ratingCounts.containsKey(rating)) {
	                                ratingCounts.put(rating, ratingCounts.get(rating) + 1);
	                            } else {
	                                ratingCounts.put(rating, 1);
	                            }
	                           
	                            uniqueRatings.add(rating);
	                         
	                            totalRatings++;
	                            sumRatings += rating;
	                        }
	                    } catch (NumberFormatException e) {
	                        
	                        //System.err.println("Invalid rating format: " + data[2]);
	                    }
	                }
	            }
	        } catch (IOException e) {
	            System.err.println("Error reading file: " + e.getMessage());
	        }

	        // Calculate average rating
	        double averageRating = (double) sumRatings / totalRatings;

	        System.out.printf("Average Rating: %.2f\n", averageRating);

	        System.out.println("Individual Rating Counts:");
	        for (int rating : uniqueRatings) {
	            String category = getRatingCategory(rating);
	            int count = ratingCounts.getOrDefault(rating, 0);
	            System.out.printf("%s: %d\n", category, count);
	        }
	    }

	    public static String getRatingCategory(int rating) {
	        switch (rating) {
	            case 1:
	                return "1 - VERY BAD";
	            case 2:
	                return "2 - BAD";
	            case 3:
	                return "3 - AVERAGE";
	            case 4:
	                return "4 - GOOD";
	            case 5:
	                return "5 - EXCELLENT";
	            default:
	                return "Unknown";
	        }
	    }
	 
	public static void enterFeedback(String name, String busId) {
		System.out.println("Give us Rating according to your feedback : \n"
						 + "1 - VERY BAD\n"
						 + "2 - BAD\n"
						 + "3 - AVERAGE\n"
						 + "4 - GOOD\n"
						 + "5 - EXCELLENT\n");
		System.out.println("Enter your number from above choices : ");
		int rating = scanner.nextInt();
		scanner.nextLine();
		if (rating < 1 && rating > 5) {
			System.out.println("Invalid Rating Choice\n Please Try Again");
			enterFeedback(name,busId);
			return;
		}
		
		StringBuilder feedback = new StringBuilder();

        System.out.println("Please enter empty line when you want to submit feedback ");
        System.out.println("Provide Your Feedback : ");

        while (true) {
            String line = scanner.nextLine();
            if (line.isEmpty()) {  
                break;
            }
            feedback.append(line).append("\n");
        }

        String[] feedbackData = {name, busId, String.valueOf(rating), feedback.toString()};
        updateUserFeedbackForm(feedbackData);
    }
		
	
	public static void updateUserFeedbackForm(String[] feedbackData) {
		try(FileWriter fw = new FileWriter(passengerFeedbackDB,true);
				PrintWriter pw = new PrintWriter(fw);){
			StringBuilder sb = new StringBuilder();
			for (String data : feedbackData) {
				sb.append(data).append(",");
			}
			 sb.setLength(sb.length() - 1);
	            // Write the data
	            pw.println(sb.toString());
	            System.out.println("Feedback recorded successfully!");
	            UserFunctionSystem.main(new String[]{"arg1", "arg2"});
	            
		} catch (IOException e) {
			e.printStackTrace();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	
	public static void FeedbackForm() {
		System.out.println("^^^^^^^^^^^^^Your feedback is invaluable to us.^^^^^^^^^^^^^^\n"
						 + "Please share your experience to help us improve our services \n"
				         + "\n"
				         + "-----------------------------------------------------------------"
				         + "User Feedback Form \n"
				         + "----------------------------------------------------------------- ");
		System.out.println("Enter your Name      : ");
		String name = scanner.nextLine();
		System.out.println("Enter you Bus number : ");
		String busId = scanner.nextLine();
		boolean checkPassenger = checkPassengerIdentity(busId,name);
		if (checkPassenger) {
			System.out.println("Please Provide Your Valuable Feedback "+name);
			enterFeedback(name,busId);
		}
		else {
			System.out.println("Passenger Identity Not Matched\n"
							 + "Sorry for interruption\n"
							 + "Please re-enter the details");
		}
		
	}
	
	

}
