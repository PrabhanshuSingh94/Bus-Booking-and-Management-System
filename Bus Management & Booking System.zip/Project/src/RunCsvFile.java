import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class RunCsvFile {
    private static String filePath = "BusDetails.csv";
    private static int noOfSeat = 30;
    private String[] busDetails = new String[8];
    private int[] busCapacity;
    private List<String[]> allRows = new ArrayList<>();
    private String[] busD;

    public void searchBus(String boardingPoint, String droppingPoint, String date) throws Exception {
        String line, bus[];
        
        System.out.println("Availabe Buses from " + boardingPoint + " to "+ droppingPoint + " On "+date);
        System.out.println("Bus No. | Boarding Point Time   | Dropping Point Time | Price | Availabe Seats");
        int availSeat = 30;
        int busCount = 0;
        try (FileReader file = new FileReader(filePath);
             BufferedReader br = new BufferedReader(file)) {
            while ((line = br.readLine()) != null) {
            	
                bus = line.split(",");
                allRows.add(bus);
                
                if (bus.length > 2 && bus[5].equals(boardingPoint) && bus[6].equals(droppingPoint) && bus[0].equals(date)) {
                    busCapacity = new int[noOfSeat];

                    for (int i = 0; i < 8; i++) {
                        busDetails[i] = bus[i];
                    }
                    for (int i = 0; i < busCapacity.length; i++) {
                        busCapacity[i] = Integer.parseInt(bus[i + 8]);
                        if (busCapacity[i] == 1) {
                        	availSeat -= 1;
                        }
                    }
                
                    
                    
                    System.out.println(" "+busDetails[4]+"     "+busDetails[0]+ "  " +busDetails[1] +
                    					"       "+busDetails[2] + "  " + busDetails[3]+"     " + busDetails[7]+"       "+availSeat);
                    
                }
                else {
                	busCount += 1;
                	//System.out.println("Bus not found");
                }
            }
            if(busCount == allRows.size()) {
            	System.out.println("The Bus you are trying to found for the route "+boardingPoint+" to "+droppingPoint +" on\n"
            					 + date +" is not available. We are sorry for the inavailability of the service...");
            	System.out.println("You will be redirected to the home page...");
            	UserFunctionSystem.main(new String[]{"arg1", "arg2"});
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    
    public void readAllRows() {
        String line;
        try (FileReader file = new FileReader(filePath);
             BufferedReader br = new BufferedReader(file)) {
            while ((line = br.readLine()) != null) {
                allRows.add(line.split(","));
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public List<String[]> getAllRows() {
        return allRows;
    }

    
    public void searchBus(String busId,String date) {
        String line, bus[];
        List<String[]> allRows = new ArrayList<>();
        try (FileReader file = new FileReader(filePath);
             BufferedReader br = new BufferedReader(file)) {
            while ((line = br.readLine()) != null) {
                bus = line.split(",");
                allRows.add(bus);

                if (bus.length > 2 && bus[4].equals(busId) && bus[0].equals(date)) {
                    busCapacity = new int[noOfSeat];
                    
                    for (int i = 0; i < 8; i++) {
                        busDetails[i] = bus[i];
                    }
                    for (int i = 0; i < busCapacity.length; i++) {
                        busCapacity[i] = Integer.parseInt(bus[i + 8]);
                    }
                    
                   
                }
                
                
            }
        } catch (IOException e) {
        	
            e.printStackTrace();
        }
        
    }
    
   
    
   
    
	public String[] getBusDetails() {
		if (busCapacity == null) {
	        return new String[]{"No bus details found"}; 
	    }
	    return busDetails;
	}
	
	public int[] getBusCapacity() {
		if (busCapacity == null) {
	        return new int[]{-1}; 
	    }
	    return busCapacity;
	}
	
	
	
}

