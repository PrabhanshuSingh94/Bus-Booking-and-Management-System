import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class FeedbackProcessor {
    private static final int FEEDBACKS_PER_PAGE = 5;
    private static Scanner scanner = new Scanner(System.in);

    public static void displayFeedback() {
        // Load and display the first page of feedbacks
        List<String> feedbacks = loadFeedbacks("passengerFeedback.csv");
        displayFeedbacks(feedbacks, 0);
        
        // Handle showing more feedbacks based on user input
        handleMoreFeedbacks(feedbacks);
    }

    public static List<String> loadFeedbacks(String fileName) {
        List<String> feedbacks = new ArrayList<>();
        try (BufferedReader br = new BufferedReader(new FileReader(fileName))) {
            String line;
            while ((line = br.readLine()) != null) {
                String[] data = line.split(",");
                if (data.length >= 4) { // Ensure there's at least feedback data
                    String name = data[0];
                    String feedback = data[3]; // Feedback is at index 3
                    feedbacks.add(name + " : " + feedback);
                }
            }
        } catch (IOException e) {
            System.err.println("Error reading file: " + e.getMessage());
        }
        return feedbacks;
    }

    public static void displayFeedbacks(List<String> feedbacks, int startIndex) {
        System.out.println("===== Feedback Comments =====");
        int endIndex = Math.min(startIndex + FEEDBACKS_PER_PAGE, feedbacks.size());
        for (int i = startIndex; i < endIndex; i++) {
            System.out.println(feedbacks.get(i));
        }
        System.out.println("=============================");
    }

    public static void handleMoreFeedbacks(List<String> feedbacks) {
        int startIndex = FEEDBACKS_PER_PAGE;
        while (true) {
            System.out.println("Press 1 to see more feedbacks, or any other key to exit:");
            String input = scanner.nextLine();
            if ("1".equals(input)) {
                displayFeedbacks(feedbacks, startIndex);
                startIndex += FEEDBACKS_PER_PAGE;
            } else {
                break;
            }
        }
        System.out.println("End of feedbacks.");
    }
}
